package MagiHax.God.ShenYue;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.Signature;
import it.unimi.dsi.fastutil.BigArrays;
import java.security.MessageDigest;
import kotlin.Metadata;
import kotlin.Pair;
import kotlin.TuplesKt;
import kotlin.collections.ArraysKt;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;

@Metadata(d1 = {"\u00002\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\b\n\u0002\b\u0005\n\u0002\u0010\u0012\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\bÆ\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J\u0010\u0010\n\u001a\u00020\u00042\u0006\u0010\u000b\u001a\u00020\fH\u0002J\u001a\u0010\r\u001a\u000e\u0012\u0004\u0012\u00020\u000f\u0012\u0004\u0012\u00020\u00040\u000e2\u0006\u0010\u0010\u001a\u00020\u0011J\f\u0010\u0012\u001a\u00020\u0004*\u00020\fH\u0002R\u000e\u0010\u0003\u001a\u00020\u0004XD¢\u0006\u0002\n\u0000R\u001e\u0010\u0007\u001a\u00020\u00062\u0006\u0010\u0005\u001a\u00020\u0006@BX\u000e¢\u0006\b\n\u0000\u001a\u0004\b\b\u0010\t¨\u0006\u0013"}, d2 = {"LMagiHax/God/ShenYue/AntiModification;", "", "()V", "SIGN_HASH", "", "<set-?>", "", "call", "getCall", "()I", "hash", "sig", "", "validateAppSignature", "Lkotlin/Pair;", "", "context", "Landroid/content/Context;", "toHex", "app_debug"}, k = 1, mv = {1, 6, 0}, xi = 48)
/* compiled from: AntiModification.kt */
public final class AntiModification {
    public static final AntiModification INSTANCE = new AntiModification();
    private static final String SIGN_HASH = "7804ec4ecb06606c042a896fc75eb10a";
    private static int call;

    private AntiModification() {
    }

    public final int getCall() {
        return call;
    }

    public final Pair<Boolean, String> validateAppSignature(Context context) {
        Intrinsics.checkNotNullParameter(context, "context");
        PackageInfo packageInfo = context.getPackageManager().getPackageInfo(context.getPackageName(), BigArrays.SEGMENT_SIZE);
        call++;
        Signature[] apkContentsSigners = packageInfo.signingInfo.getApkContentsSigners();
        Intrinsics.checkNotNullExpressionValue(apkContentsSigners, "packageInfo.signingInfo.apkContentsSigners");
        int length = apkContentsSigners.length;
        int i = 0;
        while (i < length) {
            Signature signature = apkContentsSigners[i];
            i++;
            byte[] byteArray = signature.toByteArray();
            Intrinsics.checkNotNullExpressionValue(byteArray, "signature.toByteArray()");
            if (Intrinsics.areEqual((Object) hash(byteArray), (Object) SIGN_HASH)) {
                return TuplesKt.to(true, "fuck signature killer");
            }
        }
        return TuplesKt.to(false, "ur mom");
    }

    private final String hash(byte[] sig) {
        call++;
        MessageDigest digest = MessageDigest.getInstance("MD5");
        digest.update(sig);
        byte[] digest2 = digest.digest();
        Intrinsics.checkNotNullExpressionValue(digest2, "digest.digest()");
        return toHex(digest2);
    }

    private final String toHex(byte[] $this$toHex) {
        return ArraysKt.joinToString$default($this$toHex, (CharSequence) "", (CharSequence) null, (CharSequence) null, 0, (CharSequence) null, (Function1) AntiModification$toHex$1.INSTANCE, 30, (Object) null);
    }
}
